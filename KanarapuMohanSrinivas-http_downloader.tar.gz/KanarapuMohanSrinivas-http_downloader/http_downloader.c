#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <netdb.h>
#include <pthread.h>

#define SERVER_PORT "443"
#define MAX_URL_LENGTH 250

struct ServerData {
    struct addrinfo server_info;
    char server_ip[INET6_ADDRSTRLEN];
    char server_url[MAX_URL_LENGTH];
    char output_filename[200];
    char file_path[MAX_URL_LENGTH];
    char output_extension[20];
    int start_byte;
    int end_byte;
    int part_number;
};

void initialize_ssl_library() {
    SSL_library_init(); 
    SSL_load_error_strings();	
    OpenSSL_add_ssl_algorithms();
}

int create_socket() {
    int socket_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (socket_fd < 0) {
        perror("Failed to create socket");
        exit(EXIT_FAILURE);
    }
    return socket_fd;
}

void connect_to_server(int socket_fd, struct addrinfo *server_address) {
    if (connect(socket_fd, server_address->ai_addr, server_address->ai_addrlen) != 0) {
        perror("Connection to the server failed");
        close(socket_fd);
        exit(EXIT_FAILURE);
    }
}

SSL_CTX* create_ssl_context() {
    SSL_CTX *context;
    const SSL_METHOD *method = SSLv23_client_method();
    context = SSL_CTX_new(method);
    if (!context) {
        perror("Failed to create SSL context");
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }
    return context;
}

SSL* create_ssl_connection(int socket_fd, SSL_CTX *context, const char *server_ip) {
    SSL *ssl = SSL_new(context);
    if (!ssl || SSL_set_tlsext_host_name(ssl, server_ip) <= 0 || SSL_set_fd(ssl, socket_fd) == 0 || SSL_connect(ssl) < 0) {
        perror("SSL connection error");
        ERR_print_errors_fp(stderr);
        close(socket_fd);
        SSL_free(ssl);
        SSL_CTX_free(context);
        exit(EXIT_FAILURE);
    }
    return ssl;
}

FILE* create_file_for_writing(const char *filename) {
    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("File could not be opened");
        exit(EXIT_FAILURE);
    }
    return file;
}

void send_http_request(SSL *ssl, const char *http_request) {
    if (SSL_write(ssl, http_request, strlen(http_request)) <= 0) {
        perror("Error writing to SSL connection");
        ERR_print_errors_fp(stderr);
        SSL_free(ssl);
        exit(EXIT_FAILURE);
    }
}

void read_write_data(SSL *ssl, int socket_fd, const char *filename, int start_byte, int end_byte) {
    char buffer[1280000];
    while (1) {
        int num_bytes = SSL_read(ssl, buffer, sizeof(buffer));
        if (num_bytes <= 0) {
            break;
        }
        char *b = strstr(buffer, "\r\n\r\n");
        int offset = b - buffer + 4;
        if ((offset < end_byte - start_byte) && offset > 0) {
            char *t = buffer + offset;
        } else {
            FILE *file = fopen(filename, "ab");
            if (file != NULL) {
                fwrite(buffer, num_bytes, 1, file);
                fclose(file);
            }
            else{
                perror("File could not be opened");
                close(socket_fd);
                SSL_free(ssl);
                exit(EXIT_FAILURE);
            }
        }
        memset(buffer, 0, sizeof(buffer));
    }
    
}


void *download_file_segment(void *server_data) {
    struct ServerData *server = (struct ServerData*)server_data;

    int socket_fd = create_socket();
    connect_to_server(socket_fd, &(server->server_info));

    SSL_CTX *context = create_ssl_context();
    SSL *ssl = create_ssl_connection(socket_fd, context, server->server_ip);
    SSL_set_tlsext_host_name(ssl, server->server_ip); // Use server IP or hostname here

    char http_request[512]; // Increased size to accommodate larger headers
    snprintf(http_request, sizeof(http_request),
             "GET %s HTTP/1.1\r\n"
             "Host: %s\r\n"
             "Range: bytes=%d-%d\r\n"
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
             "Connection: close\r\n\r\n",
             server->file_path, server->server_ip, server->start_byte, server->end_byte);

    send_http_request(ssl, http_request);

    char filename[100];
    snprintf(filename, sizeof(filename), "part_%d", server->part_number);

    // Assuming read_write_data correctly handles opening the file, reading data from SSL, and writing to the file
    read_write_data(ssl, socket_fd, filename, server->start_byte, server->end_byte);

    SSL_free(ssl);
    SSL_CTX_free(context);
    close(socket_fd);

    return NULL;
}

int get_remote_file_size(struct ServerData *server_data) {
    initialize_ssl_library();

    int socket_fd = create_socket();
    connect_to_server(socket_fd, &(server_data->server_info));

    SSL_CTX *context = create_ssl_context();
    SSL *ssl = create_ssl_connection(socket_fd, context, server_data->server_ip);
    SSL_set_tlsext_host_name(ssl, server_data->server_ip);

    char http_request[1024];
    snprintf(http_request, sizeof(http_request),
             "HEAD /%s HTTP/1.1\r\n"
             "Host: %s\r\n"
             "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
             "Connection: close\r\n\r\n",
             server_data->file_path, server_data->server_ip);

    send_http_request(ssl, http_request);

    char response[4096] = {0};
    char *ptr = response;
    int num_bytes, total_bytes = 0;
    while ((num_bytes = SSL_read(ssl, ptr, sizeof(response) - 1 - total_bytes)) > 0) {
        ptr += num_bytes;
        total_bytes += num_bytes;
        // Check if the end of the header section is reached
        if (strstr(response, "\r\n\r\n") != NULL) {
            break;
        }
    }

    if (num_bytes < 0) {
        int err = SSL_get_error(ssl, num_bytes);
        fprintf(stderr, "SSL_read failed: %s\n", ERR_error_string(err, NULL));
    }

    // Ensure the response string is null-terminated
    response[total_bytes] = '\0';

    printf("Response: %s\n", response);

    // Extract Content-Length
    int content_length = -1;
    char *content_length_start = strstr(response, "Content-Length: ");
    if (content_length_start) {
        content_length_start += strlen("Content-Length: ");
        content_length = atoi(content_length_start);
    }

    // Cleanup
    SSL_free(ssl);
    SSL_CTX_free(context);
    close(socket_fd);

    return content_length;
}

void initialize_server_data(struct ServerData *server, char *url) {
    struct addrinfo server_info, *server_address;
    
    char input_url[MAX_URL_LENGTH];
    char duplicate_url[MAX_URL_LENGTH];
    char *parsed_url;
    strcpy(input_url, url);
    strcpy(duplicate_url, url);
    char *ptr = strtok(duplicate_url, "//");


    ptr = strtok(NULL, "//");

    char *result;
    int position;
    result = strstr(input_url, ptr);
    if (result != NULL) {
        position = result - input_url + strlen(ptr);
        int substring_length = strlen(input_url) - position;
        parsed_url = malloc(substring_length + 1);
    }
    else {
        fprintf(stderr, "'ptr' not found in 'input_url'\n");
    }
    int q = 0;
    for (int p = position; p <= strlen(input_url); p++) {
        parsed_url[q] = input_url[p];
        q = q + 1;
    }
    
    memset(&server_info, 0, sizeof(server_info));
    server_info.ai_family = AF_INET;
    server_info.ai_socktype = SOCK_STREAM;

    int status = getaddrinfo(ptr, SERVER_PORT, &server_info, &server_address);


    if ( status == 0){
        //pass;
    }
    else {
        fprintf(stderr, "Error in getaddrinfo: %s\n", gai_strerror(status));
        free(parsed_url);
        exit(EXIT_FAILURE);
    }
    server->server_info = *server_address;
    strcpy(server->file_path, parsed_url);
    
    for (struct addrinfo *addr = server_address; addr != NULL; addr = addr->ai_next) {
        void *numeric_address;
        char address_buffer[INET6_ADDRSTRLEN];
        numeric_address = &((struct sockaddr_in *)addr->ai_addr)->sin_addr;

        if (inet_ntop(addr->ai_addr->sa_family, numeric_address, address_buffer,
                      sizeof(address_buffer)) == NULL)
            perror("Invalid IP address");
        else {
            strcpy(server->server_ip, address_buffer);
            free(parsed_url);
            return;
        }
    }
    
    free(parsed_url);
}

int main(int argc, char **argv)
{
    char *url = NULL, *num_threads = NULL, *output_file = NULL;

    // Parse command-line options using getopt
    for (int i = 1; i < argc; i += 2) {
        int option = getopt(argc, argv, "u:n:o:");

        if (option == -1) {
            // No more options
            break;
        }

        switch (option) {
            case 'u':
                // -u option: URL to download from
                url = optarg;
                break;
            case 'n':
                // -n option: Number of threads to use
                num_threads = optarg;
                break;
            case 'o':
                // -o option: Output file name
                output_file = optarg;
                break;
            case '?':
                // Invalid option or missing argument
                fprintf(stderr, "Invalid option or missing argument for option '%c'\n", optopt);
            default:
                // Print usage message and exit on any unexpected input
                fprintf(stderr, "Usage: %s -u <url> -n <num_threads> -o <output_directory>\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }
    printf("here");
    // Initialize the threads
    int thread_count = atoi(num_threads);
    pthread_t thread_id[thread_count];


    // Initialize the server data
    struct ServerData *server_data = malloc(sizeof(struct ServerData));
    strcpy(server_data->output_filename, output_file);

    const char *dot = strrchr(output_file, '.');
    if (!(!dot || dot == output_file)) {
        strcpy(server_data->output_extension, dot + 1);
    }

    initialize_server_data(server_data, url);
    int file_size = get_remote_file_size(server_data);
    
    int each_size = file_size / thread_count;
    
    struct ServerData *thread_data[thread_count];
    for (int i = 0; i < thread_count; i++) {
        thread_data[i] = malloc(sizeof(struct ServerData));
        strcpy(thread_data[i]->output_filename, output_file);
        initialize_server_data(thread_data[i], url);
        thread_data[i]->part_number = i + 1;
        thread_data[i]->start_byte = i * each_size;
        thread_data[i]->end_byte = (i != thread_count - 1) ? ((i + 1) * each_size) - 1 : file_size;
    }

    for (int i = 0; i < thread_count; i++) {
        int  type = pthread_create(&thread_id[i], NULL, download_file_segment, thread_data[i]);
        if ( type != 0) {
            fprintf(stderr, "Error: Thread was not created, ERROR CODE: %d\n", type);
            exit(EXIT_FAILURE);
        }
    }

    FILE *output_file_fd = NULL;
    output_file_fd = fopen(output_file, "wb");

    int data_range;
    for (int i = 0; i < thread_count; ++i) {  
        if (i != thread_count - 1)
            data_range = (thread_data[i]->end_byte - thread_data[i]->start_byte) + 1;
            
        else
            data_range = thread_data[i]->end_byte - thread_data[i]->start_byte;
        
        void *status;
        int temp = pthread_join(thread_id[i], &status);
        if (temp != 0) {
            fprintf(stderr, "Execution of thread failed, thread number: %d\n", i);
            exit(EXIT_FAILURE);
        }
        FILE *data_file = NULL;
        char filename[100], data[data_range];
        sprintf(filename, "part_%d", (i + 1));
        data_file = fopen(filename, "rb");
        if (data_file == NULL) {
            fprintf(stderr, "Could not open file: %s\n", filename);
            exit(EXIT_FAILURE);
        }
        fread(data, data_range, 1, data_file);
        fwrite(data, data_range, 1, output_file_fd);
        fclose(data_file);
    }
    fclose(output_file_fd);
   
    return 0;
}